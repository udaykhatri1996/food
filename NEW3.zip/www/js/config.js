
var krms_config ={		
	'ApiUrl':"https://www.dubaires.udaytech.in/mobileapp/api",				
	'DialogDefaultTitle':"Uday Food App ",	
	'APIHasKey':"",
	'debug': false
};
